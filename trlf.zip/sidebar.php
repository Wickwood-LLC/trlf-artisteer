
<?php if(theme_has_layout_part("default_sidebar")) : ?>

<?php theme_print_sidebar('primary-widget-area', '<div class="art-layout-cell art-sidebar1">', '</div>'); ?>

<?php endif; ?>
