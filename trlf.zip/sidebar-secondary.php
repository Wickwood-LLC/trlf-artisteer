
<?php if(theme_has_layout_part("secondary_sidebar")) : ?>

<?php theme_print_sidebar('secondary-widget-area', '<div class="art-layout-cell art-sidebar2">', '</div>'); ?>

<?php endif; ?>
